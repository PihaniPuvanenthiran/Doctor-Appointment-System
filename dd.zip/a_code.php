<?php
session_start();
require 'database_connection.php';

if(isset($_POST['delete_appointment']))
{
    $appointment_id = mysqli_real_escape_string($con, $_POST['delete_appointment']);

    $query = "DELETE FROM appointment WHERE appointment_id='$appointment_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Appointment Deleted Successfully";
        header("Location: appointment.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Appointment Not Deleted";
        header("Location: appointment.php");
        exit(0);
    }
}



if(isset($_POST['update_appointment']))
{
    $appointment_id = mysqli_real_escape_string($con, $_POST['appointment_id']);

    $patient_name = mysqli_real_escape_string($con, $_POST['patient_name']);
    $doctor_name = mysqli_real_escape_string($con, $_POST['doctor_name']);
    $appointment_date = mysqli_real_escape_string($con, $_POST['appointment_date']);
    $appointment_reason = mysqli_real_escape_string($con, $_POST['appointment_reason']);
    
    
    $query = "UPDATE appointment SET patient_name='$patient_name', doctor_name='$doctor_name', appointment_date='$appointment_date', appointment_reason='$appointment_reason' WHERE  appointment_id='$appointment_id' ";
    $query_run = mysqli_query($con, $query);


    if($query_run)
    {
        $_SESSION['message'] = "Appointment Updated Successfully";
        header("Location: appointment.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = " Appointment Not Updated";
        header("Location: appointment.php");
        exit(0);
    }

}






if(isset($_POST['save']))
{
    $patient_name = mysqli_real_escape_string($con, $_POST['patient_name']);
    $doctor_name = mysqli_real_escape_string($con, $_POST['doctor_name']);
    $appointment_date = mysqli_real_escape_string($con, $_POST['appointment_date']);
    $appointment_reason = mysqli_real_escape_string($con, $_POST['appointment_reason']);
    
    $query = "INSERT INTO appointment (patient_name,doctor_name,appointment_date,appointment_reason) VALUES ('$patient_name','$doctor_name','$appointment_date', '$appointment_reason')";

    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Appointment Created Successfully";
        header("Location: appointment_form.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Patient Not Created";
        header("Location: appointment_form.php");
        exit(0);
    }
}




?>