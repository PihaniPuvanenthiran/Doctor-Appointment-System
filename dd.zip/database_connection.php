<?php

$con = mysqli_connect("localhost","root","","doctor_appointment");

// Query to retrieve appointment information including patient and doctor details
$sql = "SELECT appointment.appointment_id, 
               patient.patient_name, 
               doctor.doctor_name, 
               doctor.specialization, 
               appointment.appointment_date
        FROM appointment
        JOIN patient ON appointment.patient_id = patient.patient_id
        JOIN doctor ON appointment.doctor_id = doctor.doctor_id";

$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "Appointment ID: " . $row["appointment_id"] . "<br>";
        echo "Patient Name: " . $row["patient_name"] . "<br>";
        echo "Doctor Name: " . $row["doctor_name"] . "<br>";
        echo "Specialization: " . $row["specialization"] . "<br>";
        echo "Appointment Date: " . $row["appointment_date"] . "<br>";
        echo "<br>";
    }
} else {
    echo "No appointments found.";
}

// Close the database connection
mysqli_close($con);

if(!$con){
    die('Connection Failed'. mysqli_connect_error());
}

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}



?>